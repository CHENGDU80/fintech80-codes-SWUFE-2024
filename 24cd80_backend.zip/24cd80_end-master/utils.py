class Params:
    def __init__(self, Car_make: str, Car_model: str, Car_year: int,
                 Car_accident_count: int, Car_total_mileage: float,
                 Car_drive_type: str, AV_system: str, AV_solution: str,
                 AV_chip: str, AV_level: str, AV_response_speed: float,
                 AV_system_version: str, AV_mileage: float,
                 Driver_sex: str, Driver_age: int, Driver_insurance_years: int, Driver_experience: int,
                 Driver_license_level: str, Driver_driving_mileage: float,
                 Driver_violations_count: int, Driver_accident_count: int,
                 Driver_health_status: str, Driver_credit_score: int,
                 Driver_education_level: str, Driver_occupation: str,
                 Driver_hobbies: list, Driver_hometown: str):
        """
        初始化车辆信息对象

        :param Car_make: 车辆品牌
        :param Car_model: 车辆型号
        :param Car_year: 车辆生产年份
        :param Car_accident_count: 车辆事故总数
        :param Car_total_mileage: 车辆总里程数
        :param Car_drive_type: 车辆驱动类别
        :param AV_system: 智驾系统
        :param AV_solution: 智驾方案
        :param AV_chip: 智驾芯片
        :param AV_level: 智驾级别（如L2，L3）
        :param AV_response_speed: 智驾相应速度
        :param AV_system_version: 智驾系统版本
        :param AV_mileage: 智驾里程数
        :param Driver_sex: 司机性别
        :param Driver_age: 司机年龄
        :param Driver_experience: 司机驾龄
        :param Driver_license_level: 司机驾驶级别
        :param Driver_driving_mileage: 司机驾驶里程
        :param Driver_violations_count: 司机违章总数
        :param Driver_accident_count: 司机事故总数
        :param Driver_health_status: 司机健康状况
        :param Driver_credit_score: 司机信用等级
        :param Driver_education_level: 司机教育水平
        :param Driver_occupation: 司机职业
        :param Driver_hobbies: 司机爱好
        :param Driver_hometown: 司机户籍
        """
        self.Car_make = Car_make
        self.Car_model = Car_model
        self.Car_year = Car_year
        self.Car_accident_count = Car_accident_count
        self.Car_total_mileage = Car_total_mileage
        self.Car_drive_type = Car_drive_type
        self.AV_system = AV_system
        self.AV_solution = AV_solution
        self.AV_chip = AV_chip
        self.AV_level = AV_level
        self.AV_response_speed = AV_response_speed
        self.AV_system_version = AV_system_version
        self.AV_mileage = AV_mileage
        self.Driver_sex = Driver_sex
        self.Driver_age = Driver_age
        self.Driver_insurance_years = Driver_insurance_years
        self.Driver_experience = Driver_experience
        self.Driver_license_level = Driver_license_level
        self.Driver_driving_mileage = Driver_driving_mileage
        self.Driver_violations_count = Driver_violations_count
        self.Driver_accident_count = Driver_accident_count
        self.Driver_health_status = Driver_health_status
        self.Driver_credit_score = Driver_credit_score
        self.Driver_education_level = Driver_education_level
        self.Driver_occupation = Driver_occupation
        self.Driver_hobbies = Driver_hobbies
        self.Driver_hometown = Driver_hometown