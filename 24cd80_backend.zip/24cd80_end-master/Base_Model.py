from utils import Params

def Base_Model(container):
    # 使用容器中的参数
    # 使用容器中的参数
    driver_age = container.Driver_age
    driving_mileage = container.Driver_driving_mileage
    av_level = container.AV_level
    health_status = container.Driver_health_status
    violations_count = container.Driver_violations_count
    driving_experience = container.Driver_experience
    accidents_count = container.Driver_accident_count
    insurance_years = container.Driver_insurance_years

    # 初始化调整系数
    adjustment_factor = 0.0
    base_premium = 3950

    # 正向参数
    if driver_age >= 5:
        adjustment_factor -= 0.10  # 驾驶年龄
    adjustment_factor -= (driving_mileage // 1000) * 0.02  # 驾驶里程
    if av_level in ['L2', 'L3', 'L4']:  # 假设L2及以上级别
        adjustment_factor -= 0.05  # 智能驾驶

    # 负向参数
    if health_status == 'Poor':
        adjustment_factor += 0.10  # 健康状态
    if driving_experience < 2:
        adjustment_factor += 0.15  # 驾龄
    adjustment_factor += violations_count * 0.05  # 违章次数
    adjustment_factor += accidents_count * 0.10  # 事故次数

    # 参保年限折扣
    if insurance_years >= 5:
        discount = 0.20
    elif insurance_years == 4:
        discount = 0.15
    elif insurance_years == 3:
        discount = 0.10
    elif insurance_years == 2:
        discount = 0.05
    else:
        discount = 0.0

    # 计算最终保费
    insurance_price = base_premium * (1 + adjustment_factor) * (1 - discount)

    # 限制保险费用在基础保费的 80% 到 120% 之间
    min_price = base_premium * 0.8
    max_price = base_premium * 1.2
    insurance_price = max(min(insurance_price, max_price), min_price)

    return insurance_price


insurance_info = Params(
    Car_make='Huawei',
    Car_model='Wenjie',
    Car_year=2022,
    Car_accident_count=1,
    Car_total_mileage=15000.0,
    Car_drive_type='FWD',
    AV_system='NCA',
    AV_solution='HuaweiMDC',
    AV_chip='MDC_610',
    AV_level='L2',
    AV_response_speed=6.0,
    AV_system_version='1.0.0',
    AV_mileage=4700.0,
    Driver_sex='Female',
    Driver_age=28,
    Driver_experience=6,
    Driver_insurance_years=3,
    Driver_license_level='C1',
    Driver_driving_mileage=22000.0,
    Driver_violations_count=2,
    Driver_accident_count=0,
    Driver_health_status='Healthy',
    Driver_credit_score=750,
    Driver_education_level='Master',
    Driver_occupation='Software Engineer',
    Driver_hobbies=['Reading', 'Cycling'],
    Driver_hometown='San Francisco'
)

print(Base_Model(insurance_info))


