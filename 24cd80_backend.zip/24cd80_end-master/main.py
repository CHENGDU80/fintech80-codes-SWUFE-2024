
from flask import Flask, jsonify, request
from flask_cors import CORS
import pymysql
import pandas as pd

app = Flask(__name__)
CORS(app)


# 数据库连接配置
db_config = {
    'host': '10.8.23.92',
    'port': 53306,
    'user': 'cd80',
    'password': 'nQ3ymy8BrWnXG6zW',
    'database': 'cd80',
}

def create_db_connection():
    """ 创建数据库连接 """
    return pymysql.connect(**db_config)


@app.route("/to_db", methods=['GET', 'POST'])
def uploadFile():
    try:
        print('get_all_data')
        token_value = request.args.get('token_value',  type=str)
        print(token_value)

        connection = create_db_connection()
        with connection.cursor() as cursor:
            # 使用参数化查询防止 SQL 注入
            sql2 = " SELECT * FROM records WHERE token = %s "
            cursor.execute(sql2, (token_value,))
            result = cursor.fetchall()
            print(result)

        return jsonify({"message": "数据库操作成功", "data": result}), 200
    except pymysql.MySQLError as e:
        print(f"Database Error: {e}")
        return jsonify({"message": "数据库操作失败", "error": str(e)}), 501
    except Exception as e:
        print(f"General Error: {e}")
        return jsonify({"message": "未知错误", "error": str(e)}), 502


if __name__ == '__main__':
    app.run(debug=False, host='0.0.0.0', port=5000)
