from flask import Flask, render_template

app = Flask(__name__, static_url_path='/assets', static_folder='assets')

@app.route('/')
def home():
    return render_template('login.html')

@app.route('/<path:filename>')
def template(filename):
    return render_template(filename)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=2222, debug=True)